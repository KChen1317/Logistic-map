These file are to be used to test the file import fuctionality of the program:
---Should Pass:
test.txt
test compare to test.txt
---Should Fail:
test invalid form.txt
test dict type change fail.txt
test dict type wrong key.txt
test wrong data type.txt
test neg float.txt
test zero float.txt
README.txt
